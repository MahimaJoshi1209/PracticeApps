import { Component, OnInit, Input, SimpleChanges, OnChanges } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { StudentService } from "src/app/student/student.service";

@Component({
  selector: "app-student-crud",
  templateUrl: "./student-crud.component.html",
  styleUrls: ["./student-crud.component.css"]
})
export class StudentCRUDComponent implements OnInit, OnChanges {
  Genders = ["Male", "Female"];
  studentForm: FormGroup;
  @Input() student: any;

  constructor(private ser: StudentService) {}

  ngOnInit() {
    this.studentForm = new FormGroup({
      studentId: new FormControl(null, Validators.required),
      studentName: new FormControl(null, Validators.required),
      gender: new FormControl("Male"),
      admissionDate: new FormControl(null),
      age: new FormControl(null),
      dept: new FormControl(null)
    });

    // this.studentForm.patchValue({
    //   studentId: 0,
    //   studentName: 'Checked',
    //   admissionDate: new Date().toISOString().substring(0,10),
    //   age: 39,
    //   gender: ""
    // });

    this.ser.messageSource.subscribe(data => {
      debugger;
      if(data)
      {
      debugger;
      this.studentForm.patchValue({
        studentId: data.studentId,
        studentName: data.studentName,
        gender: data.gender,
        admissionDate: new Date(data.admissionDate).toISOString().substring(0,10),
        age: data.age,
        dept: data.department
      });
    }
    })
  }
  
  onSubmit() {
    debugger;
    this.ser.addStudent(this.studentForm.value).subscribe(
      res => {
        alert("Student Added");
      },
      err => {
        console.log(err);
      }
    );
  }
  ngOnChanges(changes: SimpleChanges): void {
    debugger;
  }
}
