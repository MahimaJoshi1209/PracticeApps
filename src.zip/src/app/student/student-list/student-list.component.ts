import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { StudentService } from "src/app/student/student.service";
import { Student } from "../student.model";

@Component({
  selector: "app-student-list",
  templateUrl: "./student-list.component.html",
  styleUrls: ["./student-list.component.css"]
})
export class StudentListComponent implements OnInit {
  @Output() stuenrtClicked = new EventEmitter<any>();
  students: Student[];
  student: Student;
  tableHeader: Array<string>;
  constructor(private service: StudentService) {}

  ngOnInit() {
    this.service.refreshList().subscribe((x: Student[]) => {
      this.students = x;
    });
    for (let th in this.student) {
      this.tableHeader.push(th);
    }
  }

  populateForm(stu: Student) {
    debugger;
    this.service.sendStudent(stu);    
  }

}
