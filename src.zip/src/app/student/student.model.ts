export class Student{
    public studentId:string;
    public studentName:string;
    public gender:string;
    public admissionDate:string;
    public age:number;
    public department:string;

    /**
     *
     */
    constructor(id:string,name:string,gender:string,doa:string,age:number,dept:string) {
        this.studentId=id;
        this.studentName=name;
        this.gender=gender;
        this.admissionDate=doa;
        this.age=age;
        this.department=dept;
    }
    
}