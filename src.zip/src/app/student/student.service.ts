import { Injectable, EventEmitter, Output } from "@angular/core";
import { Student } from "./student.model";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {  BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData: Student;
  readonly rootURL = "http://localhost:5000/api";
   messageSource = new BehaviorSubject<Student>(null);

  list: Student[];

  @Output()
  notifyBack: EventEmitter<Student>;

  constructor(private http: HttpClient) {
    // this.notifyBack = new EventEmitter<Student>();
    
  }
  refreshList() {
    return this.http.get(this.rootURL + "/Student");
  }

  addStudent(formData: Student) {
    let headers = new HttpHeaders({ "Content-Type": "application/json" });
    let options = { headers: headers };
    return this.http.post(this.rootURL + "/Student", formData, options);
  }

  sendStudent(stu: Student) {
    debugger;
    this.messageSource.next(stu);    
  }


  // getStudent(): Observable<any> {
  //   debugger;
  //   return this._subject.asObservable();
  // }
}
